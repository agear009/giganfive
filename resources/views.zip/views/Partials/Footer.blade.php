<!-- ======= Footer ======= -->
<footer id="footer">
  <div class="container">
    <h3>GIGANFIVE</h3>
    <p>PT Gigan Five Corps Universal is an export company that provides agricultural products, products and mines originating from Indonesia..</p>
    <div class="social-links">
        <a href="https://www.instagram.com/giganfive_crops_universal?igsh=ZGUzMzM3NWJiOQ%3D%3D" target="blank" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="https://api.whatsapp.com/send?phone=62811204409" class="linkedin" target="blank"><i class="bi bi-whatsapp"></i></i></i></a>
    </div>

    <div class="credits">

    </div>
  </div>
</footer><!-- End Footer -->
<a href="https://api.whatsapp.com/send?phone=6282128248883" class="back-to-top d-flex align-items-center justify-content-center" target="blank"><i class="bi bi-whatsapp"></i></i></a>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>

